# IB CYBER — 3D Cybersecurity Portfolio

A modern, responsive, 3D cybersecurity portfolio designed for GitHub Pages.

## Files
- `index.html` — main website
- `style.css` — design and responsive layout
- `script.js` — 3D background and interactions

## GitHub Pages
1. Create a new GitHub repository.
2. Upload these three files to the repository root.
3. Open **Settings → Pages**.
4. Under **Build and deployment**, choose **Deploy from a branch**.
5. Select **main** and **/ (root)**.
6. Save and wait for GitHub Pages to publish the site.

## Personalize
Replace the Facebook, LinkedIn and email links in `index.html` with your real profile URLs.
