const canvas=document.getElementById("bg3d");
const scene=new THREE.Scene();
const camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,1000);
camera.position.z=8;
const renderer=new THREE.WebGLRenderer({canvas,alpha:true,antialias:true});
renderer.setPixelRatio(Math.min(devicePixelRatio,2));
renderer.setSize(innerWidth,innerHeight);

const group=new THREE.Group(); scene.add(group);
const geo=new THREE.IcosahedronGeometry(3.7,2);
const mat=new THREE.MeshBasicMaterial({color:0x6fffe9,wireframe:true,transparent:true,opacity:.08});
const mesh=new THREE.Mesh(geo,mat); group.add(mesh);

const points=new THREE.BufferGeometry();
const count=700;
const pos=new Float32Array(count*3);
for(let i=0;i<count*3;i++) pos[i]=(Math.random()-.5)*30;
points.setAttribute("position",new THREE.BufferAttribute(pos,3));
const pmat=new THREE.PointsMaterial({color:0x6fffe9,size:.025,transparent:true,opacity:.7});
scene.add(new THREE.Points(points,pmat));

let mx=0,my=0;
addEventListener("mousemove",e=>{
  mx=(e.clientX/innerWidth-.5)*.5;
  my=(e.clientY/innerHeight-.5)*.5;
});
function animate(){
  requestAnimationFrame(animate);
  mesh.rotation.x+=.0007; mesh.rotation.y+=.001;
  group.rotation.y+=(mx-group.rotation.y)*.02;
  group.rotation.x+=(my-group.rotation.x)*.02;
  renderer.render(scene,camera);
}
animate();
addEventListener("resize",()=>{
  camera.aspect=innerWidth/innerHeight; camera.updateProjectionMatrix();
  renderer.setSize(innerWidth,innerHeight);
});

const menu=document.querySelector(".menu-btn"), nav=document.querySelector("#navLinks");
menu.addEventListener("click",()=>{
  nav.style.display=nav.style.display==="flex"?"none":"flex";
  nav.style.position="absolute";nav.style.top="78px";nav.style.left="0";nav.style.right="0";
  nav.style.padding="25px";nav.style.background="rgba(5,7,11,.96)";
  nav.style.flexDirection="column";nav.style.alignItems="center";
});
document.querySelectorAll("nav a").forEach(a=>a.addEventListener("click",()=>{if(innerWidth<901)nav.style.display="none"}));
