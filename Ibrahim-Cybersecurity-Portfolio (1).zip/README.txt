# Ibrahim Cybersecurity Portfolio

A personal cybersecurity portfolio website for Ibrahim.

## Files
- `index.html` — website structure
- `style.css` — design and responsive layout
- `script.js` — mobile menu interaction

## How to open
Double-click `index.html` to preview it in your browser.

## Important
The LinkedIn button currently points to the LinkedIn Feed URL you provided. For a portfolio, replace it with your actual LinkedIn profile URL when you have it.

The GitHub button currently points to `https://github.com/`; replace it with your GitHub profile after you create it.
